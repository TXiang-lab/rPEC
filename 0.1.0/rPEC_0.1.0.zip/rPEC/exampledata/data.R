library(rPEC)
valid_id_file=c("47487","47637", "47687", "47897", "47941" ,"47948" ) 
train_id_file=c("40896" ,"40914", "44376","46860" ,"46943" ,"46943")

a=PEC(
      hap_file_name="example.hap",
      sample_file_name="example.sample",
      valid_id=valid_id_file,
      train_id=train_id_file,
      return_result=TRUE,
      win_size=10,
      threads=30)

str(a)






